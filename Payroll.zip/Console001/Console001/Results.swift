//
//  Results.swift
//  Console001
//
//  Created by wmendozak on 2023-02-06.
//

import Foundation

struct Results:Codable {
    var id:Int?
    var url:String?
    var name:String?
    var description:String?
    var attribution:String?
    var datePublished:String?
}
