//
//  main.swift
//  Console001
//
//  Created by wmendozak on 2023-02-02.
//

import Foundation

extension Date{
    func startOfMonth() -> Date {
        return Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: Calendar.current.startOfDay(for: Date())))!
    }
    func endOfMonth() -> Date {
        return Calendar.current.date(byAdding: DateComponents(month: 1, day: -1), to: self.startOfMonth())!
    }
}
//GET CURRENT DAY
let current_date = Date()

print(current_date)

let components = Calendar.current.dateComponents([.day, .hour, .weekday], from: current_date)
let day = components.day!
var hour = components.hour!
var weekday = components.weekday!

//GET LAST DAY
let last_components = Calendar.current.dateComponents([.day], from: Date().endOfMonth())
let last_day = last_components.day!
var diff_days = last_day - day


/*
hour = 10
diff_days = 0
print("hour: \(hour) - weekday: \(weekday) - day: \(day) - diff: \(diff_days)")
*/

//print(displayMessage(diff_days: diff_days, hour: hour, weekday: weekday))
print("""
Q1 - PAYROLL ASSISTANCE
=======================
""")
var payrollManager = Payroll()
print(payrollManager.displayMessage(diff_days: diff_days, hour: hour, weekday: weekday))

print(String(repeating: "-", count: 50))
print("""


Q2 - PRIME LIST
===============
""")

var numberList : [Int] = []
var evenList : [Int] = []
var oddList : [Int] = []

for _ in 1...10{
    numberList.append(Int.random(in: 1...100))
}

print("NUMBERS TO EVALUATE:")
numberList.forEach{ number in
    print(number, terminator: " ")
}

print("")
for number in numberList{
    if number % 2 == 0{
        evenList.append(number)
    } else {
        oddList.append(number)
    }
}

print("EVEN NUMBERS")
evenList.forEach{ number in
    print(number, terminator: " ")
}

print("")
print("ODD NUMBERS")
oddList.forEach{ number in
    print(number, terminator: " ")
}

print("")
print(String(repeating: "-", count: 50))
print("""


Q3 - CAR INTEREST CALCULATOR
============================
""")

let car_price : Double = 23299
var interest_rate, amount : Double
var period : Int
//period = Int(readLine()!)!
period = 10
if period < 15 {
    interest_rate = 0.04
}else{
    interest_rate = 0.032
}

amount = car_price * pow(1 + interest_rate , Double(period))

print(String(format: "Amount : %.2f", amount))

print("")
print(String(repeating: "-", count: 50))
print("""


Q4 - CAR INTEREST CALCULATOR
============================
""")

func getJson() {
    let urlString = "https://tools.cdc.gov/api/v2/resources/media"
    //let url = URL(string: urlString)!
    /*guard url != nil else {
        return
    }*/
    
    //let dataTask = URLSession.shared.dataTask(with: url) { data, response, error in
    let dataTask = URLSession.shared.dataTask(with: URL(string: urlString)!) { data, response, error in
        if error == nil && data != nil {
            print("paso")
            let decoder = JSONDecoder()
            
            do{
                let newsFeed = try decoder.decode(ResultJson.self, from: data!)
                print(newsFeed)
            }
            catch{
                print("Error in JSON parsing")
            }
        }
    }
    dataTask.resume()
}

getJson()



