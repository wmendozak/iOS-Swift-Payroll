//
//  PayrollManager.swift
//  Console001
//
//  Created by wmendozak on 2023-02-03.
//

import Foundation

class Payroll {

    func displayMessage(diff_days: Int, hour: Int, weekday: Int) -> String {
        let monday = "It is still %d days until payday"
        let tuesday = "There are %d days until payday"
        let wednesday = "Happy hump day, only %d days until payday"
        let thursday = "We are getting there. Only %d days until payday"
        let friday = "Only %d beautiful days until payday"
        let weekend = "Don't worry about it, it's the weekend "
        let out_work = "Work is over - ask me "
        var message = ""
        
        if diff_days == 0 {
            message = "It's here!"
        }
        else if hour < 8 {
            message = out_work + "later"
        }
        else if hour >= 17 && weekday == 6 {
            message = weekend
        }
        else if hour >= 17 {
            message = out_work + "tomorrow"
        }
        else{
            switch weekday {
            case 2:
                message = String(format: monday, diff_days)
            case 3:
                message = String(format: tuesday, diff_days)
            case 4:
                message = String(format: wednesday, diff_days)
            case 5:
                message = String(format: thursday, diff_days)
            case 6:
                message = String(format: friday, diff_days)
            default:
                message = weekend
            }
        }
        return message
    }
}
