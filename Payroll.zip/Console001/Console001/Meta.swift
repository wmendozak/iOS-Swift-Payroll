//
//  Meta.swift
//  Console001
//
//  Created by wmendozak on 2023-02-06.
//

import Foundation

struct Meta: Codable {
    var status:Int
}
