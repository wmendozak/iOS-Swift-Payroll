//
//  ResultJson.swift
//  Console001
//
//  Created by wmendozak on 2023-02-06.
//

import Foundation

struct ResultJson:Codable{
    var meta:Meta
    var results:[Results]?
}
